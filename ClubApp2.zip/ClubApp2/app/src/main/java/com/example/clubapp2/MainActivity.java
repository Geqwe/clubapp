package com.example.clubapp2; //folder the source code belongs to

import androidx.annotation.NonNull; //libraries
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class MainActivity extends AppCompatActivity {  //class is a set of objects that share a common structure

    private EditText Email; //variables, private = only we can see them
    private EditText Password;
    private TextView Register;
    private Button Login;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) { //onCreate=function, void=returns nothing
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();

        Email = (EditText)findViewById(R.id.etEmail); //find what we placed in design
        Password = (EditText)findViewById(R.id.etPassword);
        Register = (TextView)findViewById(R.id.btnRegister);
        Login = (Button)findViewById(R.id.btnLogin);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { //press the button to Login
                validate(Email.getText().toString(), Password.getText().toString()); //check if input is valid
            }
        });

        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { //press the button to Register
                startActivity(new Intent(MainActivity.this, RegisterActivity.class));
            }
        });

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                if(firebaseAuth.getCurrentUser() != null) {
                    startActivity(new Intent(MainActivity.this, HomePage.class));
                }
            }
        };
    }

    @Override
    protected void onStart() { //Function, void means that it returns nothing
        super.onStart();

        mAuth.addAuthStateListener(mAuthListener);
    }

    private void validate(String Email, String userPass) { //defines function "validate"
        if(TextUtils.isEmpty(Email) || TextUtils.isEmpty(userPass)) { //Checks if fields are empty and prints a message if they are
            Toast.makeText(MainActivity.this,"Fields can't be empty", Toast.LENGTH_LONG).show();
        }
        else {
            mAuth.signInWithEmailAndPassword(Email, userPass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) { //Checks if email and password match
                    if(!task.isSuccessful()) {
                        Toast.makeText(MainActivity.this,"Sign in Problem", Toast.LENGTH_LONG).show(); //If they don't match, it prints an error
                    }
                }
            });
        }


    }
}
